import { Routes, Route } from "react-router-dom";

// ================= Pages =================
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Trainers from "./pages/Trainers";
import Members from "./pages/Members";
import Plans from "./pages/Plans";
import Attendance from "./pages/Attendance";
import Payments from "./pages/Payments";
import Reports from "./pages/Reports";
import NotFound from "./pages/NotFound";

// ================= Components =================
import ProtectedRoute from "./components/ProtectedRoute";
import Layout from "./components/Layout";

function App() {
  return (
    <Routes>

      {/* ================= Public Route ================= */}
      <Route path="/" element={<Login />} />

      {/* ================= Dashboard ================= */}
      <Route
        path="/dashboard"
        element={
          <ProtectedRoute>
            <Layout>
              <Dashboard />
            </Layout>
          </ProtectedRoute>
        }
      />

      {/* ================= Trainers ================= */}
      <Route
        path="/trainers"
        element={
          <ProtectedRoute>
            <Layout>
              <Trainers />
            </Layout>
          </ProtectedRoute>
        }
      />

      {/* ================= Members ================= */}
      <Route
        path="/members"
        element={
          <ProtectedRoute>
            <Layout>
              <Members />
            </Layout>
          </ProtectedRoute>
        }
      />

      {/* ================= Plans ================= */}
      <Route
        path="/plans"
        element={
          <ProtectedRoute>
            <Layout>
              <Plans />
            </Layout>
          </ProtectedRoute>
        }
      />

      {/* ================= Attendance ================= */}
      <Route
        path="/attendance"
        element={
          <ProtectedRoute>
            <Layout>
              <Attendance />
            </Layout>
          </ProtectedRoute>
        }
      />

      {/* ================= Payments ================= */}
      <Route
        path="/payments"
        element={
          <ProtectedRoute>
            <Layout>
              <Payments />
            </Layout>
          </ProtectedRoute>
        }
      />

      {/* ================= Reports ================= */}
      <Route
        path="/reports"
        element={
          <ProtectedRoute>
            <Layout>
              <Reports />
            </Layout>
          </ProtectedRoute>
        }
      />

      {/* ================= 404 Page ================= */}
      <Route path="*" element={<NotFound />} />

    </Routes>
  );
}

export default App;