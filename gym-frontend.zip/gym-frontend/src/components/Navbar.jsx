import { NavLink } from "react-router-dom";

function Sidebar() {
  return (
    <div
      className="bg-dark text-white p-3"
      style={{
        width: "250px",
        minHeight: "100vh",
      }}
    >
      <h3 className="text-center mb-4">
        🏋️ Gym Admin
      </h3>

      <ul className="nav flex-column">

        <li className="nav-item mb-2">
          <NavLink
            to="/dashboard"
            className="nav-link text-white"
          >
            📊 Dashboard
          </NavLink>
        </li>

        <li className="nav-item mb-2">
          <NavLink
            to="/trainers"
            className="nav-link text-white"
          >
            🏋️ Trainers
          </NavLink>
        </li>

        <li className="nav-item mb-2">
          <NavLink
            to="/members"
            className="nav-link text-white"
          >
            👥 Members
          </NavLink>
        </li>

        <li className="nav-item mb-2">
          <NavLink
            to="/plans"
            className="nav-link text-white"
          >
            📦 Plans
          </NavLink>
        </li>

        <li className="nav-item mb-2">
          <NavLink
            to="/attendance"
            className="nav-link text-white"
          >
            📅 Attendance
          </NavLink>
        </li>

        <li className="nav-item mb-2">
          <NavLink
            to="/payments"
            className="nav-link text-white"
          >
            💰 Payments
          </NavLink>
        </li>

        <li className="nav-item mb-2">
          <NavLink
            to="/reports"
            className="nav-link text-white"
          >
            📈 Reports
          </NavLink>
        </li>

      </ul>
    </div>
  );
}

export default Sidebar;