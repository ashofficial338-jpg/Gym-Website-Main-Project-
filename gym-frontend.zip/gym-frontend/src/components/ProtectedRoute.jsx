import { Navigate } from "react-router-dom";

function ProtectedRoute({ children }) {
  // Get JWT Token from Local Storage
  const token = localStorage.getItem("token");

  // If token not found, redirect to Login Page
  if (!token) {
    return <Navigate to="/" replace />;
  }

  // If token exists, show the requested page
  return children;
}

export default ProtectedRoute;