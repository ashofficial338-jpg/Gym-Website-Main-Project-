import { useEffect, useState } from "react";
import API from "../services/api";

function Attendance() {
  const [attendance, setAttendance] = useState([]);

  const [record, setRecord] = useState({
    member: "",
    date: "",
    status: "Present",
  });

  const [editId, setEditId] = useState(null);

  useEffect(() => {
    getAttendance();
  }, []);

  // Get Attendance
  const getAttendance = async () => {
    try {
      const res = await API.get("/attendance");
      setAttendance(res.data.attendance);
    } catch (err) {
      console.log(err);
    }
  };

  // Handle Input
  const handleChange = (e) => {
    setRecord({
      ...record,
      [e.target.name]: e.target.value,
    });
  };

  // Add / Update Attendance
  const saveAttendance = async (e) => {
    e.preventDefault();

    try {
      if (editId) {
        await API.put(`/attendance/${editId}`, record);
        alert("Attendance Updated Successfully");
      } else {
        await API.post("/attendance", record);
        alert("Attendance Added Successfully");
      }

      setRecord({
        member: "",
        date: "",
        status: "Present",
      });

      setEditId(null);

      getAttendance();
    } catch (err) {
      console.log(err);
      alert("Operation Failed");
    }
  };

  // Edit Attendance
  const editAttendance = (a) => {
    setRecord({
      member: a.member?._id || "",
      date: a.date?.split("T")[0] || "",
      status: a.status,
    });

    setEditId(a._id);
  };

  // Delete Attendance
  const deleteAttendance = async (id) => {
    if (!window.confirm("Delete attendance record?")) return;

    try {
      await API.delete(`/attendance/${id}`);
      alert("Attendance Deleted Successfully");
      getAttendance();
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <div className="container mt-4">

      <h2 className="mb-4">Attendance Management</h2>

      <form onSubmit={saveAttendance}>

        <input
          className="form-control mb-2"
          placeholder="Member ID"
          name="member"
          value={record.member}
          onChange={handleChange}
          required
        />

        <input
          type="date"
          className="form-control mb-2"
          name="date"
          value={record.date}
          onChange={handleChange}
          required
        />

        <select
          className="form-control mb-3"
          name="status"
          value={record.status}
          onChange={handleChange}
        >
          <option>Present</option>
          <option>Absent</option>
        </select>

        <button className="btn btn-success">
          {editId ? "Update Attendance" : "Mark Attendance"}
        </button>

      </form>

      <hr />

      <table className="table table-bordered table-striped">

        <thead className="table-dark">
          <tr>
            <th>Member</th>
            <th>Date</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>

        <tbody>

          {attendance.length > 0 ? (
            attendance.map((a) => (
              <tr key={a._id}>
                <td>{a.member?.name || "-"}</td>
                <td>{new Date(a.date).toLocaleDateString()}</td>
                <td>{a.status}</td>

                <td>
                  <button
                    className="btn btn-warning btn-sm me-2"
                    onClick={() => editAttendance(a)}
                  >
                    Edit
                  </button>

                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => deleteAttendance(a._id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="4" className="text-center">
                No Attendance Records Found
              </td>
            </tr>
          )}

        </tbody>

      </table>

    </div>
  );
}

export default Attendance;