import { useEffect, useState } from "react";
import API from "../services/api";

function Trainers() {
  const [trainers, setTrainers] = useState([]);

  const [trainer, setTrainer] = useState({
    name: "",
    specialization: "",
    phone: "",
  });

  const [editId, setEditId] = useState(null);

  useEffect(() => {
    getTrainers();
  }, []);

  // ================= Get Trainers =================
  const getTrainers = async () => {
    try {
      const res = await API.get("/trainers");
      setTrainers(res.data.trainers);
    } catch (err) {
      console.log(err);
    }
  };

  // ================= Handle Input =================
  const handleChange = (e) => {
    setTrainer({
      ...trainer,
      [e.target.name]: e.target.value,
    });
  };

  // ================= Add / Update Trainer =================
  const addTrainer = async (e) => {
    e.preventDefault();

    try {
      if (editId) {
        await API.put(`/trainers/${editId}`, trainer);
        alert("Trainer Updated Successfully");
      } else {
        await API.post("/trainers", trainer);
        alert("Trainer Added Successfully");
      }

      setTrainer({
        name: "",
        specialization: "",
        phone: "",
      });

      setEditId(null);

      getTrainers();
    } catch (err) {
      console.log(err);
      alert("Operation Failed");
    }
  };

  // ================= Edit Trainer =================
  const editTrainer = (t) => {
    setTrainer({
      name: t.name,
      specialization: t.specialization,
      phone: t.phone,
    });

    setEditId(t._id);
  };

  // ================= Delete Trainer =================
  const deleteTrainer = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this trainer?"
    );

    if (!confirmDelete) return;

    try {
      await API.delete(`/trainers/${id}`);

      alert("Trainer Deleted Successfully");

      getTrainers();
    } catch (err) {
      console.log(err);
      alert("Delete Failed");
    }
  };

  return (
    <div className="container mt-4">

      <h2 className="mb-4">Trainer Management</h2>

      {/* Add / Update Form */}

      <form onSubmit={addTrainer} className="mb-4">

        <input
          type="text"
          name="name"
          placeholder="Trainer Name"
          className="form-control mb-2"
          value={trainer.name}
          onChange={handleChange}
          required
        />

        <input
          type="text"
          name="specialization"
          placeholder="Specialization"
          className="form-control mb-2"
          value={trainer.specialization}
          onChange={handleChange}
          required
        />

        <input
          type="text"
          name="phone"
          placeholder="Phone Number"
          className="form-control mb-3"
          value={trainer.phone}
          onChange={handleChange}
          required
        />

        <button className="btn btn-success">
          {editId ? "Update Trainer" : "Add Trainer"}
        </button>

      </form>

      {/* Trainer Table */}

      <table className="table table-bordered table-striped">

        <thead className="table-dark">
          <tr>
            <th>Name</th>
            <th>Specialization</th>
            <th>Phone</th>
            <th width="180">Actions</th>
          </tr>
        </thead>

        <tbody>

          {trainers.length > 0 ? (
            trainers.map((t) => (
              <tr key={t._id}>
                <td>{t.name}</td>
                <td>{t.specialization}</td>
                <td>{t.phone}</td>

                <td>
                  <button
                    className="btn btn-warning btn-sm me-2"
                    onClick={() => editTrainer(t)}
                  >
                    Edit
                  </button>

                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => deleteTrainer(t._id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="4" className="text-center">
                No Trainers Found
              </td>
            </tr>
          )}

        </tbody>

      </table>

    </div>
  );
}

export default Trainers;