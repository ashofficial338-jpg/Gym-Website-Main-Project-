import { useEffect, useState } from "react";
import API from "../services/api";

function Plans() {
  const [plans, setPlans] = useState([]);

  const [plan, setPlan] = useState({
    name: "",
    duration: "",
    price: "",
  });

  const [editId, setEditId] = useState(null);

  useEffect(() => {
    getPlans();
  }, []);

  // Get Plans
  const getPlans = async () => {
    try {
      const res = await API.get("/plans");
      setPlans(res.data.plans);
    } catch (err) {
      console.log(err);
    }
  };

  // Handle Input
  const handleChange = (e) => {
    setPlan({
      ...plan,
      [e.target.name]: e.target.value,
    });
  };

  // Add / Update Plan
  const savePlan = async (e) => {
    e.preventDefault();

    try {
      if (editId) {
        await API.put(`/plans/${editId}`, plan);
        alert("Plan Updated Successfully");
      } else {
        await API.post("/plans", plan);
        alert("Plan Added Successfully");
      }

      setPlan({
        name: "",
        duration: "",
        price: "",
      });

      setEditId(null);

      getPlans();
    } catch (err) {
      console.log(err);
      alert("Operation Failed");
    }
  };

  // Edit Plan
  const editPlan = (p) => {
    setPlan({
      name: p.name,
      duration: p.duration,
      price: p.price,
    });

    setEditId(p._id);
  };

  // Delete Plan
  const deletePlan = async (id) => {
    if (!window.confirm("Delete this plan?")) return;

    try {
      await API.delete(`/plans/${id}`);
      alert("Plan Deleted Successfully");
      getPlans();
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <div className="container mt-4">

      <h2 className="mb-4">Plan Management</h2>

      <form onSubmit={savePlan}>

        <input
          className="form-control mb-2"
          placeholder="Plan Name"
          name="name"
          value={plan.name}
          onChange={handleChange}
          required
        />

        <input
          className="form-control mb-2"
          placeholder="Duration (Months)"
          type="number"
          name="duration"
          value={plan.duration}
          onChange={handleChange}
          required
        />

        <input
          className="form-control mb-3"
          placeholder="Price"
          type="number"
          name="price"
          value={plan.price}
          onChange={handleChange}
          required
        />

        <button className="btn btn-success">
          {editId ? "Update Plan" : "Add Plan"}
        </button>

      </form>

      <hr />

      <table className="table table-bordered table-striped">

        <thead className="table-dark">
          <tr>
            <th>Name</th>
            <th>Duration</th>
            <th>Price</th>
            <th>Actions</th>
          </tr>
        </thead>

        <tbody>

          {plans.length > 0 ? (
            plans.map((p) => (
              <tr key={p._id}>
                <td>{p.name}</td>
                <td>{p.duration} Months</td>
                <td>₹{p.price}</td>

                <td>
                  <button
                    className="btn btn-warning btn-sm me-2"
                    onClick={() => editPlan(p)}
                  >
                    Edit
                  </button>

                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => deletePlan(p._id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="4" className="text-center">
                No Plans Found
              </td>
            </tr>
          )}

        </tbody>

      </table>

    </div>
  );
}

export default Plans;