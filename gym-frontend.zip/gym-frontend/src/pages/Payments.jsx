import { useEffect, useState } from "react";
import API from "../services/api";

function Payments() {
  const [payments, setPayments] = useState([]);

  const [payment, setPayment] = useState({
    member: "",
    amount: "",
    paymentDate: "",
    paymentMethod: "Cash",
  });

  const [editId, setEditId] = useState(null);

  useEffect(() => {
    getPayments();
  }, []);

  // Get Payments
  const getPayments = async () => {
    try {
      const res = await API.get("/payments");
      setPayments(res.data.payments);
    } catch (err) {
      console.log(err);
    }
  };

  // Handle Input
  const handleChange = (e) => {
    setPayment({
      ...payment,
      [e.target.name]: e.target.value,
    });
  };

  // Add / Update Payment
  const savePayment = async (e) => {
    e.preventDefault();

    try {
      if (editId) {
        await API.put(`/payments/${editId}`, payment);
        alert("Payment Updated Successfully");
      } else {
        await API.post("/payments", payment);
        alert("Payment Added Successfully");
      }

      setPayment({
        member: "",
        amount: "",
        paymentDate: "",
        paymentMethod: "Cash",
      });

      setEditId(null);
      getPayments();
    } catch (err) {
      console.log(err);
      alert("Operation Failed");
    }
  };

  // Edit Payment
  const editPayment = (p) => {
    setPayment({
      member: p.member?._id || "",
      amount: p.amount,
      paymentDate: p.paymentDate?.split("T")[0] || "",
      paymentMethod: p.paymentMethod,
    });

    setEditId(p._id);
  };

  // Delete Payment
  const deletePayment = async (id) => {
    if (!window.confirm("Delete this payment?")) return;

    try {
      await API.delete(`/payments/${id}`);
      alert("Payment Deleted Successfully");
      getPayments();
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Payment Management</h2>

      <form onSubmit={savePayment}>
        <input
          className="form-control mb-2"
          placeholder="Member ID"
          name="member"
          value={payment.member}
          onChange={handleChange}
          required
        />

        <input
          type="number"
          className="form-control mb-2"
          placeholder="Amount"
          name="amount"
          value={payment.amount}
          onChange={handleChange}
          required
        />

        <input
          type="date"
          className="form-control mb-2"
          name="paymentDate"
          value={payment.paymentDate}
          onChange={handleChange}
          required
        />

        <select
          className="form-control mb-3"
          name="paymentMethod"
          value={payment.paymentMethod}
          onChange={handleChange}
        >
          <option>Cash</option>
          <option>UPI</option>
          <option>Card</option>
        </select>

        <button className="btn btn-success">
          {editId ? "Update Payment" : "Add Payment"}
        </button>
      </form>

      <hr />

      <table className="table table-bordered table-striped">
        <thead className="table-dark">
          <tr>
            <th>Member</th>
            <th>Amount</th>
            <th>Date</th>
            <th>Method</th>
            <th>Actions</th>
          </tr>
        </thead>

        <tbody>
          {payments.length > 0 ? (
            payments.map((p) => (
              <tr key={p._id}>
                <td>{p.member?.name || "-"}</td>
                <td>₹{p.amount}</td>
                <td>{new Date(p.paymentDate).toLocaleDateString()}</td>
                <td>{p.paymentMethod}</td>

                <td>
                  <button
                    className="btn btn-warning btn-sm me-2"
                    onClick={() => editPayment(p)}
                  >
                    Edit
                  </button>

                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => deletePayment(p._id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="5" className="text-center">
                No Payments Found
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

export default Payments;