import { useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../services/api";

function Login() {
  const navigate = useNavigate();

  const [user, setUser] = useState({
    email: "",
    password: "",
  });

  const [loading, setLoading] = useState(false);

  // ================= Handle Input =================
  const handleChange = (e) => {
    setUser({
      ...user,
      [e.target.name]: e.target.value,
    });
  };

  // ================= Login =================
  const handleLogin = async (e) => {
    e.preventDefault();

    if (!user.email || !user.password) {
      return alert("Please enter Email and Password");
    }

    setLoading(true);

    try {
      const res = await API.post("/users/login", user);

      // Save JWT Token
      localStorage.setItem("token", res.data.token);

      // Save User Details (if backend returns user object)
      if (res.data.user) {
        localStorage.setItem("username", res.data.user.name);
        localStorage.setItem("email", res.data.user.email);
      }

      alert("Login Successful");

      navigate("/dashboard", { replace: true });

    } catch (err) {
      alert(err.response?.data?.message || "Login Failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="container d-flex justify-content-center align-items-center"
      style={{ minHeight: "100vh" }}
    >
      <div className="card shadow p-4" style={{ width: "400px" }}>

        <h2 className="text-center mb-4">
          🏋️ Gym Management
        </h2>

        <form onSubmit={handleLogin}>

          <div className="mb-3">
            <label className="form-label">
              Email
            </label>

            <input
              type="email"
              name="email"
              className="form-control"
              placeholder="Enter Email"
              value={user.email}
              onChange={handleChange}
              required
            />
          </div>

          <div className="mb-3">
            <label className="form-label">
              Password
            </label>

            <input
              type="password"
              name="password"
              className="form-control"
              placeholder="Enter Password"
              value={user.password}
              onChange={handleChange}
              required
            />
          </div>

          <button
            type="submit"
            className="btn btn-primary w-100"
            disabled={loading}
          >
            {loading ? "Logging in..." : "Login"}
          </button>

        </form>

      </div>
    </div>
  );
}

export default Login;